package com.example.artmapdraw;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_310;
import java.io.File;

public class ArtMapDraw implements ModInitializer {
    public static final String MOD_ID = "artmapdraw";

    @Override
    public void onInitialize() {
        // Create necessary directory structure
        File configFolder = new File(class_310.method_1551().field_1697, "config/artmapdraw");
        File imagesFolder = new File(configFolder, "images");

        if (!imagesFolder.exists()) {
            imagesFolder.mkdirs();
        }
    }
}
