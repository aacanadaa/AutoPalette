package com.example.autopalette.client;

import com.example.autopalette.client.gui.DrawScreen;
import com.example.autopalette.client.painter.AutoPainter;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ArtMapDrawClient implements ClientModInitializer {
    private static class_304 openGuiKey;

    @Override
    public void onInitializeClient() {
        // Register keybinding to open drawing screen (default key: H)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.autopalette.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                "category.autopalette"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Check if key is pressed to open DrawScreen
            while (openGuiKey.method_1436()) {
                if (client.field_1724 != null) {
                    client.method_1507(new DrawScreen());
                }
            }

            // Run the painter state machine logic each tick
            AutoPainter.INSTANCE.clientTick();
        });
    }
}
