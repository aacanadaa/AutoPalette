package com.example.autopalette.client.gui;

import com.example.autopalette.client.painter.AutoPainter;
import com.example.autopalette.client.palette.ArtMapPalette;
import javax.imageio.ImageIO;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DrawScreen extends class_437 {
    private final ArtMapPalette palette = new ArtMapPalette();
    private final List<File> imageFiles = new ArrayList<>();
    
    private int selectedImageIndex = -1;
    private int scrollOffset = 0;
    
    // Config values
    private int drawDelay = 2; // Ticks
    private boolean smoothCam = true;
    private float rotationSpeed = 30.0f;
    private int selectedOrderIndex = 4; // default to Color-Optimized
    private final String[] paintOrders = {
            "Row by Row (L to R)",
            "Row by Row (R to L)",
            "Column by Column",
            "Snake",
            "Color-Optimized"
    };
    private int ditheringModeIndex = 1; // 0 = None, 1 = Floyd-Steinberg, 2 = Bayer 4x4, 3 = Bayer 8x8
    private int maxColorsIndex = 0;
    private final int[] colorLimits = { -1, 32, 16, 8 };
    private final int previewSize = 128;

    private static final int[][] BAYER_4X4 = {
        {  0,  8,  2, 10 },
        { 12,  4, 14,  6 },
        {  3, 11,  1,  9 },
        { 15,  7, 13,  5 }
    };

    private static final int[][] BAYER_8X8 = {
        {  0, 48, 12, 60,  3, 51, 15, 63 },
        { 32, 16, 44, 28, 35, 19, 47, 31 },
        {  8, 56,  4, 52, 11, 59,  7, 55 },
        { 40, 24, 36, 20, 43, 27, 39, 23 },
        {  2, 50, 14, 62,  1, 49, 13, 61 },
        { 34, 18, 46, 30, 33, 17, 45, 29 },
        { 10, 58,  6, 54,  9, 57,  5, 53 },
        { 42, 26, 38, 22, 41, 25, 37, 21 }
    };

    // Preview texture variables
    private class_1043 previewTexture = null;
    private class_2960 previewTextureId = null;
    private ArtMapPalette.MappedColor[][] mappedColorsGrid = null;

    // Controls
    private class_4185 drawButton;
    private class_4185 orderButton;
    private class_4185 ditheringButton;
    private class_4185 smoothCamButton;
    private class_4185 delayMinusButton;
    private class_4185 delayPlusButton;
    private class_4185 settingsTabButton;
    private class_4185 materialsTabButton;
    private class_4185 matScrollUpButton;
    private class_4185 matScrollDownButton;
    private class_4185 maxColorsButton;

    // Tab state
    private boolean showMaterialsTab = false;
    private int materialScrollOffset = 0;
    private final List<MaterialEntry> materialsList = new ArrayList<>();

    public DrawScreen() {
        super(class_2561.method_43470("AutoPalette Panel v1.1.0"));
    }

    @Override
    protected void method_25426() {
        refreshImageList();

        // 1. Scroll Up Button
        method_37063(class_4185.method_46430(class_2561.method_43470("▲"), button -> {
            if (scrollOffset > 0) scrollOffset--;
        }).method_46434(10, 35, 120, 15).method_46431());

        // 2. Scroll Down Button
        method_37063(class_4185.method_46430(class_2561.method_43470("▼"), button -> {
            if (scrollOffset < Math.max(0, imageFiles.size() - 5)) scrollOffset++;
        }).method_46434(10, 145, 120, 15).method_46431());

        // 3. Selection Buttons (Image List items)
        for (int i = 0; i < 5; i++) {
            final int index = i;
            method_37063(class_4185.method_46430(class_2561.method_43470("Empty"), button -> {
                int targetIndex = scrollOffset + index;
                if (targetIndex < imageFiles.size()) {
                    selectedImageIndex = targetIndex;
                    loadSelectedImagePreview();
                }
            }).method_46434(10, 52 + i * 18, 120, 16).method_46431());
        }

        // 4. Tab Selector Buttons
        settingsTabButton = method_37063(class_4185.method_46430(class_2561.method_43470("Settings"), button -> {
            showMaterialsTab = false;
            updateTabVisibility();
        }).method_46434(145, 35, 72, 20).method_46431());

        materialsTabButton = method_37063(class_4185.method_46430(class_2561.method_43470("Materials"), button -> {
            showMaterialsTab = true;
            updateTabVisibility();
        }).method_46434(220, 35, 75, 20).method_46431());

        // 5. Config Buttons (Settings Tab)
        // Delay -
        delayMinusButton = method_37063(class_4185.method_46430(class_2561.method_43470("-"), button -> {
            if (drawDelay > 0) drawDelay--;
        }).method_46434(145, 80, 20, 20).method_46431());

        // Delay +
        delayPlusButton = method_37063(class_4185.method_46430(class_2561.method_43470("+"), button -> {
            if (drawDelay < 20) drawDelay++;
        }).method_46434(225, 80, 20, 20).method_46431());

        // Dithering Button
        ditheringButton = method_37063(class_4185.method_46430(class_2561.method_43470("Dithering: Floyd-Steinberg"), button -> {
            ditheringModeIndex = (ditheringModeIndex + 1) % 4;
            updateButtonsText();
            loadSelectedImagePreview();
        }).method_46434(145, 105, 150, 20).method_46431());

        // Smooth Camera Button
        smoothCamButton = method_37063(class_4185.method_46430(class_2561.method_43470("Smooth Cam: ON"), button -> {
            smoothCam = !smoothCam;
            updateButtonsText();
        }).method_46434(145, 130, 150, 20).method_46431());

        // Draw Order Button
        orderButton = method_37063(class_4185.method_46430(class_2561.method_43470("Order: Color-Optimized"), button -> {
            selectedOrderIndex = (selectedOrderIndex + 1) % paintOrders.length;
            updateButtonsText();
        }).method_46434(145, 155, 150, 20).method_46431());

        // Max Colors Button
        maxColorsButton = method_37063(class_4185.method_46430(class_2561.method_43470("Max Colors: Unlimited"), button -> {
            maxColorsIndex = (maxColorsIndex + 1) % colorLimits.length;
            updateButtonsText();
            loadSelectedImagePreview();
            materialScrollOffset = 0;
        }).method_46434(145, 180, 150, 20).method_46431());

        // 6. Materials Tab Scroll Buttons
        matScrollUpButton = method_37063(class_4185.method_46430(class_2561.method_43470("▲"), button -> {
            if (materialScrollOffset > 0) materialScrollOffset--;
        }).method_46434(280, 75, 15, 20).method_46431());

        // 7. Materials Tab Scroll Down Button
        matScrollDownButton = method_37063(class_4185.method_46430(class_2561.method_43470("▼"), button -> {
            if (materialScrollOffset < materialsList.size() - 8) materialScrollOffset++;
        }).method_46434(280, 100, 15, 20).method_46431());

        // 8. Start / Stop Draw Button
        drawButton = method_37063(class_4185.method_46430(class_2561.method_43470("START DRAWING"), button -> {
            if (AutoPainter.INSTANCE.isActive()) {
                AutoPainter.INSTANCE.stopPainting();
            } else if (mappedColorsGrid != null) {
                AutoPainter.INSTANCE.startPainting(
                        mappedColorsGrid,
                        drawDelay,
                        smoothCam,
                        rotationSpeed,
                        paintOrders[selectedOrderIndex]
                );
                this.method_25419();
            }
        }).method_46434(145, 205, 150, 20).method_46431());

        updateButtonsText();
        updateListButtonLabels();
    }

    private void refreshImageList() {
        imageFiles.clear();
        File folder = new File(class_310.method_1551().field_1697, "config/autopalette/images");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.getName().endsWith(".png") || file.getName().endsWith(".jpg") || file.getName().endsWith(".jpeg")) {
                    imageFiles.add(file);
                }
            }
        }
    }

    private void updateButtonsText() {
        String ditheringText = switch (ditheringModeIndex) {
            case 0 -> "None";
            case 1 -> "Floyd-Steinberg";
            case 2 -> "Bayer 4x4";
            case 3 -> "Bayer 8x8";
            default -> "None";
        };
        ditheringButton.method_25355(class_2561.method_43470("Dithering: " + ditheringText));
        smoothCamButton.method_25355(class_2561.method_43470("Smooth Cam: " + (smoothCam ? "ON" : "OFF")));
        orderButton.method_25355(class_2561.method_43470("Order: " + getShortOrderName(paintOrders[selectedOrderIndex])));
        int limit = colorLimits[maxColorsIndex];
        maxColorsButton.method_25355(class_2561.method_43470("Max Colors: " + (limit == -1 ? "Unlimited" : limit)));
        
        if (AutoPainter.INSTANCE.isActive()) {
            drawButton.method_25355(class_2561.method_43470("STOP DRAWING"));
        } else {
            drawButton.method_25355(class_2561.method_43470("START DRAWING"));
        }
    }

    private String getShortOrderName(String fullName) {
        if (fullName.contains("Row")) return "Row by Row";
        if (fullName.contains("Column")) return "Col by Col";
        return fullName;
    }

    private void updateListButtonLabels() {
        int listBtnCount = 0;
        for (var child : this.method_25396()) {
            if (child instanceof class_4185 btn) {
                if (btn.method_46426() == 10 && btn.method_46427() >= 52 && btn.method_46427() <= 124) {
                    int targetIndex = scrollOffset + listBtnCount;
                    if (targetIndex < imageFiles.size()) {
                        String name = imageFiles.get(targetIndex).getName();
                        if (name.length() > 14) {
                            name = name.substring(0, 11) + "...";
                        }
                        btn.method_25355(class_2561.method_43470(name));
                        btn.field_22763 = true;
                    } else {
                        btn.method_25355(class_2561.method_43470("- Empty -"));
                        btn.field_22763 = false;
                    }
                    listBtnCount++;
                }
            }
        }
    }

    private ArtMapPalette.MappedColor getClosestColorFrom(int r, int g, int b, Set<ArtMapPalette.PaletteEntry> allowedEntries) {
        ArtMapPalette.MappedColor closest = null;
        double minDistance = Double.MAX_VALUE;

        for (ArtMapPalette.MappedColor color : palette.getMappedColors()) {
            if (allowedEntries.contains(color.baseEntry)) {
                double dist = getColorDistance(r, g, b, color.r, color.g, color.b);
                if (dist < minDistance) {
                    minDistance = dist;
                    closest = color;
                }
            }
        }
        return closest;
    }

    private double getColorDistance(int r1, int g1, int b1, int r2, int g2, int b2) {
        long rDiff = r1 - r2;
        long gDiff = g1 - g2;
        long bDiff = b1 - b2;
        return Math.sqrt(rDiff * rDiff + gDiff * gDiff + bDiff * bDiff);
    }

    private void loadSelectedImagePreview() {
        if (selectedImageIndex < 0 || selectedImageIndex >= imageFiles.size()) return;
        File file = imageFiles.get(selectedImageIndex);

        try {
            BufferedImage originalImage = ImageIO.read(file);
            if (originalImage == null) return;

            // Resize to 128x128
            BufferedImage resized = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics = resized.createGraphics();
            graphics.drawImage(originalImage, 0, 0, 128, 128, null);
            graphics.dispose();

            // Perform color mapping
            mappedColorsGrid = new ArtMapPalette.MappedColor[128][128];
            class_1011 previewImg = new class_1011(128, 128, false);

            // Determine allowed base entries based on selected max colors limit
            int limit = colorLimits[maxColorsIndex];
            Set<ArtMapPalette.PaletteEntry> allowedBaseEntries = new HashSet<>();
            if (limit == -1) {
                allowedBaseEntries.addAll(palette.getBaseEntries());
            } else {
                Map<ArtMapPalette.PaletteEntry, Integer> frequencyMap = new HashMap<>();
                for (int y = 0; y < 128; y++) {
                    for (int x = 0; x < 128; x++) {
                        int rgb = resized.getRGB(x, y);
                        int r = (rgb >> 16) & 0xFF;
                        int g = (rgb >> 8) & 0xFF;
                        int b = rgb & 0xFF;
                        ArtMapPalette.MappedColor closest = palette.getClosestColor(r, g, b);
                        if (closest != null && closest.baseEntry != null) {
                            frequencyMap.put(closest.baseEntry, frequencyMap.getOrDefault(closest.baseEntry, 0) + 1);
                        }
                    }
                }
                List<Map.Entry<ArtMapPalette.PaletteEntry, Integer>> sortedEntries = new ArrayList<>(frequencyMap.entrySet());
                sortedEntries.sort((e1, e2) -> Integer.compare(e2.getValue(), e1.getValue()));
                for (int i = 0; i < Math.min(limit, sortedEntries.size()); i++) {
                    allowedBaseEntries.add(sortedEntries.get(i).getKey());
                }
                if (allowedBaseEntries.isEmpty() && !palette.getBaseEntries().isEmpty()) {
                    allowedBaseEntries.add(palette.getBaseEntries().get(0));
                }
            }

            if (ditheringModeIndex == 1) {
                // Floyd-Steinberg Dithering
                double[][][] rgbGrid = new double[128][128][3];
                for (int y = 0; y < 128; y++) {
                    for (int x = 0; x < 128; x++) {
                        int rgb = resized.getRGB(x, y);
                        rgbGrid[x][y][0] = (rgb >> 16) & 0xFF; // R
                        rgbGrid[x][y][1] = (rgb >> 8) & 0xFF;  // G
                        rgbGrid[x][y][2] = rgb & 0xFF;         // B
                    }
                }

                for (int y = 0; y < 128; y++) {
                    for (int x = 0; x < 128; x++) {
                        double r = Math.min(255, Math.max(0, rgbGrid[x][y][0]));
                        double g = Math.min(255, Math.max(0, rgbGrid[x][y][1]));
                        double b = Math.min(255, Math.max(0, rgbGrid[x][y][2]));

                        ArtMapPalette.MappedColor closest = getClosestColorFrom((int) r, (int) g, (int) b, allowedBaseEntries);
                        mappedColorsGrid[x][y] = closest;

                        double errR = r - closest.r;
                        double errG = g - closest.g;
                        double errB = b - closest.b;

                        distributeError(rgbGrid, x + 1, y, errR, errG, errB, 7.0 / 16.0);
                        distributeError(rgbGrid, x - 1, y + 1, errR, errG, errB, 3.0 / 16.0);
                        distributeError(rgbGrid, x, y + 1, errR, errG, errB, 5.0 / 16.0);
                        distributeError(rgbGrid, x + 1, y + 1, errR, errG, errB, 1.0 / 16.0);

                        int abgr = 0xFF000000 | (closest.b << 16) | (closest.g << 8) | closest.r;
                        previewImg.method_4305(x, y, abgr);
                    }
                }
            } else if (ditheringModeIndex == 2 || ditheringModeIndex == 3) {
                // Ordered Bayer Dithering (4x4 or 8x8)
                int size = (ditheringModeIndex == 2) ? 4 : 8;
                int[][] bayerMatrix = (ditheringModeIndex == 2) ? BAYER_4X4 : BAYER_8X8;
                double spread = 32.0;

                for (int y = 0; y < 128; y++) {
                    for (int x = 0; x < 128; x++) {
                        int rgb = resized.getRGB(x, y);
                        int origR = (rgb >> 16) & 0xFF;
                        int origG = (rgb >> 8) & 0xFF;
                        int origB = rgb & 0xFF;

                        double factor = (bayerMatrix[x % size][y % size] + 0.5) / (size * size) - 0.5;
                        int r = (int) (origR + factor * spread);
                        int g = (int) (origG + factor * spread);
                        int b = (int) (origB + factor * spread);

                        r = Math.min(255, Math.max(0, r));
                        g = Math.min(255, Math.max(0, g));
                        b = Math.min(255, Math.max(0, b));

                        ArtMapPalette.MappedColor closest = getClosestColorFrom(r, g, b, allowedBaseEntries);
                        mappedColorsGrid[x][y] = closest;

                        int abgr = 0xFF000000 | (closest.b << 16) | (closest.g << 8) | closest.r;
                        previewImg.method_4305(x, y, abgr);
                    }
                }
            } else {
                // Direct Nearest Color mapping (None)
                for (int y = 0; y < 128; y++) {
                    for (int x = 0; x < 128; x++) {
                        int rgb = resized.getRGB(x, y);
                        int r = (rgb >> 16) & 0xFF;
                        int g = (rgb >> 8) & 0xFF;
                        int b = rgb & 0xFF;

                        ArtMapPalette.MappedColor closest = getClosestColorFrom(r, g, b, allowedBaseEntries);
                        mappedColorsGrid[x][y] = closest;

                        int abgr = 0xFF000000 | (closest.b << 16) | (closest.g << 8) | closest.r;
                        previewImg.method_4305(x, y, abgr);
                    }
                }
            }

            // Update registered texture
            if (previewTexture != null) {
                previewTexture.close();
            }
            previewTexture = new class_1043(() -> "autopalette_preview", previewImg);
            previewTextureId = class_2960.method_60655("autopalette", "preview");
            class_310.method_1551().method_1531().method_4616(previewTextureId, previewTexture);
            calculateMaterialsList();
            materialScrollOffset = 0;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void distributeError(double[][][] rgbGrid, int x, int y, double errR, double errG, double errB, double factor) {
        if (x >= 0 && x < 128 && y >= 0 && y < 128) {
            rgbGrid[x][y][0] += errR * factor;
            rgbGrid[x][y][1] += errG * factor;
            rgbGrid[x][y][2] += errB * factor;
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        updateListButtonLabels();

        // Title
        context.method_27534(field_22793, field_22785, this.field_22789 / 2, 8, 0xFFFFFFFF);

        // Subtitles
        context.method_27535(field_22793, class_2561.method_43470("Images Directory"), 10, 22, 0xFFAAAAAA);
        context.method_27535(field_22793, class_2561.method_43470("Settings Panel"), 145, 22, 0xFFAAAAAA);
        context.method_27535(field_22793, class_2561.method_43470("Preview (Mapped)"), 300, 22, 0xFFAAAAAA);

        // Render preview texture box
        int previewX = 300;
        int previewY = 35;
 
        context.method_49601(previewX - 1, previewY - 1, previewSize + 2, previewSize + 2, 0xFFAAAAAA);
        if (previewTextureId != null) {
            context.method_25290(net.minecraft.class_10799.field_56883, previewTextureId, previewX, previewY, 0.0f, 0.0f, previewSize, previewSize, 128, 128);
        } else {
            context.method_25294(previewX, previewY, previewX + previewSize, previewY + previewSize, 0xFF333333);
            context.method_27534(field_22793, class_2561.method_43470("No Preview"), previewX + previewSize / 2, previewY + previewSize / 2 - 4, 0xFF777777);
        }
 
        if (!showMaterialsTab) {
            // Selected Image Label
            if (selectedImageIndex >= 0 && selectedImageIndex < imageFiles.size()) {
                String selectedName = imageFiles.get(selectedImageIndex).getName();
                if (selectedName.length() > 22) {
                    selectedName = selectedName.substring(0, 19) + "...";
                }
                context.method_27535(field_22793, class_2561.method_43470("Selected: " + selectedName), 145, 58, 0xFFFFD700);
            } else {
                context.method_27535(field_22793, class_2561.method_43470("Selected: None"), 145, 58, 0xFFFF0000);
            }
 
            // Delay display value
            context.method_27535(field_22793, class_2561.method_43470("Delay:"), 145, 72, 0xFFFFFFFF);
            context.method_27534(field_22793, class_2561.method_43470(drawDelay + " Ticks"), 195, 85, 0xFF00FF00);
        } else {
            // Render Materials List
            context.method_27535(field_22793, class_2561.method_43470("Needed Materials:"), 145, 60, 0xFFFFAAAA);
            
            int startY = 75;
            int itemsCount = Math.min(8, materialsList.size() - materialScrollOffset);
            for (int i = 0; i < itemsCount; i++) {
                MaterialEntry entry = materialsList.get(materialScrollOffset + i);
                int y = startY + i * 18;
                
                // Render item icon
                if (entry.itemId != null && !entry.itemId.isEmpty()) {
                    net.minecraft.class_1792 item = net.minecraft.class_7923.field_41178.method_63535(net.minecraft.class_2960.method_60654(entry.itemId));
                    if (item != net.minecraft.class_1802.field_8162) {
                        context.method_51427(new net.minecraft.class_1799(item), 145, y - 3);
                    }
                }

                String name = entry.name;
                if (name.length() > 13) {
                    name = name.substring(0, 11) + "..";
                }
                
                int stacks = entry.count / 64;
                int remaining = entry.count % 64;
                String amtStr = entry.count + "";
                if (stacks > 0) {
                    amtStr = stacks + "s+" + remaining;
                }
                
                context.method_27535(field_22793, class_2561.method_43470(name), 165, y, entry.color);
                context.method_27535(field_22793, class_2561.method_43470("x" + amtStr), 252, y, 0xFFBBBBBB);
            }
            
            if (materialsList.isEmpty()) {
                context.method_27535(field_22793, class_2561.method_43470("No image selected"), 145, 90, 0xFF777777);
            }
        }

        // Painter Status
        int statusY = previewY + previewSize + 10;
        context.method_27535(field_22793, class_2561.method_43470("Status:"), 300, statusY, 0xFFAAAAAA);
        context.method_27535(field_22793, class_2561.method_43470(AutoPainter.INSTANCE.getStatusText()), 300, statusY + 13, 0xFFFFFFFF);
 
        // Progress bar if painting
        if (AutoPainter.INSTANCE.isActive()) {
            int progressWidth = 110;
            int progressX = 300;
            int progressY = statusY + 28;
            int progressVal = (int) (progressWidth * (AutoPainter.INSTANCE.getProgressPercent() / 100.0));
 
            context.method_49601(progressX - 1, progressY - 1, progressWidth + 2, 8, 0xFFAAAAAA);
            context.method_25294(progressX, progressY, progressX + progressWidth, progressY + 6, 0xFF333333);
            context.method_25294(progressX, progressY, progressX + progressVal, progressY + 6, 0xFF00FF00);
        }
    }

    public static class MaterialEntry {
        public final String name;
        public final String itemId;
        public final int count;
        public final int color;

        public MaterialEntry(String name, String itemId, int count, int color) {
            this.name = name;
            this.itemId = itemId;
            this.count = count;
            this.color = color;
        }
    }

    private void calculateMaterialsList() {
        materialsList.clear();
        if (mappedColorsGrid == null) return;

        // Count dye counts for each pixel
        Map<String, Integer> dyeCounts = new HashMap<>();
        int feathersTotal = 0;
        int coalTotal = 0;

        for (int y = 0; y < 128; y++) {
            for (int x = 0; x < 128; x++) {
                ArtMapPalette.MappedColor color = mappedColorsGrid[x][y];
                if (color != null) {
                    String name = color.baseEntry.displayName;
                    dyeCounts.put(name, dyeCounts.getOrDefault(name, 0) + 1);

                    if (color.shade == ArtMapPalette.ShadeLevel.LIGHTENED) {
                        feathersTotal += 1;
                    } else if (color.shade == ArtMapPalette.ShadeLevel.DARKENED_1) {
                        coalTotal += 1;
                    } else if (color.shade == ArtMapPalette.ShadeLevel.DARKENED_2) {
                        coalTotal += 2;
                    }
                }
            }
        }

        // Sort dyes by count descending
        List<Map.Entry<String, Integer>> sortedDyes = new ArrayList<>(dyeCounts.entrySet());
        sortedDyes.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));

        // Map dye names to their item IDs from the palette
        Map<String, String> nameToId = new HashMap<>();
        for (ArtMapPalette.PaletteEntry pe : palette.getBaseEntries()) {
            nameToId.put(pe.displayName, pe.itemId);
        }

        // Populate final list of materials
        for (Map.Entry<String, Integer> entry : sortedDyes) {
            String itemId = nameToId.getOrDefault(entry.getKey(), "");
            materialsList.add(new MaterialEntry(entry.getKey(), itemId, entry.getValue(), 0xFFFFFFFF));
        }

        if (feathersTotal > 0) {
            materialsList.add(new MaterialEntry("Feather", "minecraft:feather", feathersTotal, 0xFF55FFFF));
        }
        if (coalTotal > 0) {
            materialsList.add(new MaterialEntry("Coal/Charcoal", "minecraft:coal", coalTotal, 0xFFAAAAAA));
        }
    }

    private void updateTabVisibility() {
        boolean showSettings = !showMaterialsTab;
        
        ditheringButton.field_22764 = showSettings;
        ditheringButton.field_22763 = showSettings;
        
        smoothCamButton.field_22764 = showSettings;
        smoothCamButton.field_22763 = showSettings;
        
        orderButton.field_22764 = showSettings;
        orderButton.field_22763 = showSettings;
        
        delayMinusButton.field_22764 = showSettings;
        delayMinusButton.field_22763 = showSettings;
        
        delayPlusButton.field_22764 = showSettings;
        delayPlusButton.field_22763 = showSettings;

        maxColorsButton.field_22764 = showSettings;
        maxColorsButton.field_22763 = showSettings;

        boolean showMatScroll = showMaterialsTab && materialsList.size() > 8;
        matScrollUpButton.field_22764 = showMatScroll;
        matScrollUpButton.field_22763 = showMatScroll;
        matScrollDownButton.field_22764 = showMatScroll;
        matScrollDownButton.field_22763 = showMatScroll;

        settingsTabButton.field_22763 = showMaterialsTab;
        materialsTabButton.field_22763 = !showMaterialsTab;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (showMaterialsTab && mouseX >= 145 && mouseX <= 295 && mouseY >= 60 && mouseY <= 180) {
            if (verticalAmount > 0) {
                if (materialScrollOffset > 0) materialScrollOffset--;
            } else if (verticalAmount < 0) {
                if (materialScrollOffset < materialsList.size() - 8) materialScrollOffset++;
            }
            updateTabVisibility();
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void method_25419() {
        super.method_25419();
        if (previewTexture != null) {
            previewTexture.close();
            previewTexture = null;
            previewTextureId = null;
        }
    }
}
