package com.example.autopalette;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_310;
import java.io.File;

public class ArtMapDraw implements ModInitializer {
    public static final String MOD_ID = "autopalette";

    @Override
    public void onInitialize() {
        // Create necessary directory structure
        File configFolder = new File(class_310.method_1551().field_1697, "config/autopalette");
        File imagesFolder = new File(configFolder, "images");

        if (!imagesFolder.exists()) {
            imagesFolder.mkdirs();
        }
    }
}
